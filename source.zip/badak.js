const { 
    default: makeWASocket, 
    useMultiFileAuthState, 
    DisconnectReason, 
    makeCacheableSignalKeyStore 
} = require("@primeroselotus/baileys");
const pino = require("pino");
const { Boom } = require("@hapi/boom");
const fs = require("fs");
const express = require("express");

const app = express();
let sessions = {};
let pairingCodes = {}; // Nyimpen kode buat ditampilin di APK

async function startBot(sessionName, phoneNumber = null) {
    const { state, saveCreds } = await useMultiFileAuthState(sessionName);
    const sock = makeWASocket({
        logger: pino({ level: "silent" }),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "silent" })),
        },
        browser: ["Xera Banned", "Chrome", "20.0.04"]
    });

    // Fitur Request Pairing via Web/APK
    if (!sock.authState.creds.registered && phoneNumber) {
        setTimeout(async () => {
            try {
                let code = await sock.requestPairingCode(phoneNumber.replace(/[^0-9]/g, ''));
                pairingCodes[sessionName] = code.toUpperCase();
            } catch (e) { pairingCodes[sessionName] = "LIMIT"; }
        }, 3000);
    }

    sock.ev.on("creds.update", saveCreds);
    sock.ev.on("connection.update", (up) => {
        const { connection, lastDisconnect } = up;
        if (connection === "open") { 
            sessions[sessionName] = sock; 
            delete pairingCodes[sessionName]; 
            console.log(`✅ ${sessionName} Berhasil Login!`);
        }
        if (connection === "close") {
            delete sessions[sessionName];
            if (new Boom(lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut) startBot(sessionName);
        }
    });
}

// --- TAMPILAN APK ---
app.get('/', (req, res) => {
    let listSesi = Object.keys(sessions).map(s => `<option value="${s.replace('session_', '')}">${s.replace('session_', '')}</option>`).join('') || "<option>Belum ada sender</option>";
    let codes = Object.entries(pairingCodes).map(([name, code]) => 
        `<div style="background:#222;padding:15px;margin:10px 0;border-radius:10px;border:1px solid yellow;">
            Sesi: <b>${name}</b><br>
            KODE PAIRING: <b style="color:yellow;font-size:25px;">${code}</b>
        </div>`
    ).join('');

    res.send(`
        <html>
            <head><meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body { background:#000; color:#fff; font-family:sans-serif; padding:15px; }
                .card { border:1px solid #333; padding:15px; border-radius:12px; background:#111; margin-bottom:15px; }
                input, select, button { width:100%; padding:14px; margin:8px 0; border-radius:8px; border:1px solid #444; background:#222; color:#fff; font-size:16px; }
                button { font-weight:bold; border:none; cursor:pointer; }
                .btn-banned { background:#ff0000; }
                .btn-pair { background:#0055ff; }
            </style></head>
            <body>
                <h2 style="text-align:center;color:red;margin-bottom:20px;">🛡️ XERA BANNED PANEL</h2>
                
                <div class="card">
                    <h3 style="margin-top:0;">➕ MASUKIN SENDER</h3>
                    <form action="/add-sender">
                        <input type="text" name="name" placeholder="Nama Sesi (Contoh: tumbal1)" required>
                        <input type="text" name="number" placeholder="Nomor Tumbal (628xxx)" required>
                        <button class="btn-pair">AMBIL KODE PAIRING</button>
                    </form>
                    ${codes}
                </div>

                <div class="card">
                    <h3 style="margin-top:0;">🔥 EKSEKUSI BANNED</h3>
                    <form action="/banned">
                        <label>Pilih Nomor Sender:</label>
                        <select name="session">${listSesi}</select>
                        <input type="text" name="target" placeholder="Nomor Target (628xxx)" required>
                        <input type="text" name="text" placeholder="Teks Ilegal Pancingan" required>
                        <button class="btn-banned">GAS BANNED!</button>
                    </form>
                </div>
                <p style="text-align:center;color:#444;font-size:12px;">© 2026 Xera Cpanel Anti-DDoS</p>
            </body>
        </html>
    `);
});

app.get('/add-sender', (req, res) => {
    const { name, number } = req.query;
    if (name && number) startBot(`session_${name}`, number);
    res.send("<script>alert('Tunggu bentar terus refresh!'); window.location.href='/';</script>");
});

app.get('/banned', async (req, res) => {
    const { target, session, text } = req.query;
    const client = sessions[`session_${session}`];
    if (!client) return res.send("Sender Offline!");
    try {
        const jid = `${target.replace(/[^0-9]/g, '')}@s.whatsapp.net`;
        const msg = await client.sendMessage(jid, { text: text });
        setTimeout(() => { client.reportSpam(jid, { id: msg.key.id, fromMe: true, remoteJid: jid }); }, 2000);
        res.send("<body style='background:#000;color:#fff;text-align:center;'><h1>🔥 TARGET DI-REPORT!</h1><a href='/' style='color:red;'>Balik ke APK</a></body>");
    } catch (e) { res.send("Gagal eksekusi!"); }
});

// Load otomatis sesi lama
if (fs.existsSync("./")) {
    fs.readdirSync("./").filter(f => f.startsWith("session_")).forEach(f => startBot(f));
}
app.listen(3000);
